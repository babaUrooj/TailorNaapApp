TAILOR NAAP BOOK — Android Studio project (updated)

Design:
- Warm vanilla/cream background with soft teal and subtle orange accents, inspired by your reference image.

Customer features:
- Add, search, view, edit and delete customers
- Customer name, phone, optional code and notes
- Each customer can have separate measurements for each category

Category and measurement-field management:
- Add custom categories (e.g. Kurta, Coat, Shalwar)
- Rename or delete categories
- Add, rename and delete measurement fields within each category
- Field/category deletion also removes the related saved values

Backup and restore:
- Save a JSON backup file or create backup JSON text
- Open Google Drive to upload the backup file manually
- Restore from a downloaded JSON file or pasted backup JSON
- Google Drive automatic sync is NOT enabled; it requires Google OAuth/Drive API setup. Keep backup files private.
- Data is stored locally on the phone until backed up. Clearing app data/uninstalling may erase local records.

Build APK:
1. Install Android Studio on a computer.
2. Open this TailorNaapApp folder as an existing project.
3. Allow Gradle sync/downloads.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).

Note: An APK has not been compiled in this environment because Android SDK/Gradle build tooling is not available here.

BUILD APK USING GITHUB ACTIONS (no Android Studio needed on your own computer):
1. Create/sign in to a GitHub account and create a new repository.
2. Upload the contents of this project folder to the repository (not the ZIP file itself).
3. Open the repository's Actions tab.
4. Select "Build installable APK" and click "Run workflow" (or push to main/master).
5. After a successful run, open the run and download the "Tailor-Naap-Book-APK" artifact.
   Extract the downloaded ZIP to get app-debug.apk.
6. Transfer app-debug.apk to your Android phone and open it to install. If prompted,
   allow installation from that file manager/source.

This environment does not have Android SDK/Gradle installed and cannot reach Google's
SDK download servers, so an APK has NOT been compiled or tested here. The workflow
builds it on GitHub's hosted runner when you run it.
